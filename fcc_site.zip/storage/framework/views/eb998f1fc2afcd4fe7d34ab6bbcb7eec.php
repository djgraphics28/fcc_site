<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['disabled' => false, 'value' => '']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['disabled' => false, 'value' => '']); ?>
<?php foreach (array_filter((['disabled' => false, 'value' => '']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<input <?php echo e($disabled ? 'disabled' : ''); ?> type="number" <?php echo e($attributes->merge(['class' => 'border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm', 'data-inputmask' => "'mask': '(999) 999-9999'", ])); ?> value="<?php echo e($value); ?>">

<?php $__env->startPush('contact-scripts'); ?>
    <script src="<?php echo e(asset('js/inputmask/dist/inputmask.min.js')); ?>"></script>
    <script>
        // Add contact number masking
        document.addEventListener('DOMContentLoaded', function () {
            Inputmask().mask(document.querySelector('input[name="contactNumber"]'));
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\fcc_site\resources\views/components/text-input-contact.blade.php ENDPATH**/ ?>