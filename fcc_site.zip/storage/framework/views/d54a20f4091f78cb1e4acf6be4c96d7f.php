<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['options' => [], 'selected' => []]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['options' => [], 'selected' => []]); ?>
<?php foreach (array_filter((['options' => [], 'selected' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<select multiple <?php echo e($attributes->merge(['class' => 'form-multiselect border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm'])); ?>>
    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($value); ?>" <?php echo e(in_array($value, $selected) ? 'selected' : ''); ?>><?php echo e($label); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>


<?php $__env->startPush('select-scripts'); ?>
    <script src="<?php echo e(asset('node_modules/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('node_modules/select2/dist/js/select2.min.js')); ?>"></script>
    <script>
        // Initialize Select2
        $(document).ready(function () {
            $('select[multiple]').select2();
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\laragon\www\fcc_site\resources\views/components/select-multiple.blade.php ENDPATH**/ ?>